import 'package:flutter/material.dart';

class DetailAlarmRealPage extends StatelessWidget {
  const DetailAlarmRealPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo.shade100,
      appBar: AppBar(
        title: const Text('Alarm Detail'),
        backgroundColor: Colors.indigo,
      ),
      body: const Center(
        child: Text(
          'This is the Alarm real detail page',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
